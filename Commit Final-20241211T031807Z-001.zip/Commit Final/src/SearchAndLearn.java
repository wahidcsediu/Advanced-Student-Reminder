import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.net.URI;
import java.util.ArrayList;

public class SearchAndLearn {
    private static final ArrayList<String> searchHistory = new ArrayList<>();

    public static void launch() {
        JFrame frame = new JFrame("Search and Learn");
        frame.setSize(800, 400);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        Font font = new Font("Segoe UI", Font.PLAIN, 20);
        Color backgroundColor = new Color(34, 34, 34); // Dark Gray
        Color buttonColor = new Color(50, 150, 255); // Blue
        Color disabledButtonColor = new Color(100, 100, 100); // Disabled Button

        // Create components
        JLabel lblSearch = new JLabel("Enter Topic:");
        JTextField txtSearch = new JTextField();
        JButton btnSearch = new JButton("Search on YouTube");
        JButton btnClear = new JButton("Clear");
        JComboBox<String> historyComboBox = new JComboBox<>();

        // Set component fonts
        lblSearch.setFont(font);
        lblSearch.setForeground(Color.WHITE);
        txtSearch.setFont(font);
        btnSearch.setFont(font);
        btnClear.setFont(font);

        // Set layout
        frame.setLayout(null);
        frame.getContentPane().setBackground(backgroundColor);

        // Set bounds for components
        lblSearch.setBounds(50, 60, 200, 40);
        txtSearch.setBounds(250, 60, 400, 40);
        btnSearch.setBounds(200, 150, 180, 50);
        btnClear.setBounds(400, 150, 100, 50);
        historyComboBox.setBounds(250, 100, 400, 40);

        // Apply modern button styles
        btnSearch.setBackground(buttonColor);
        btnSearch.setForeground(Color.WHITE);
        btnSearch.setFocusPainted(false);
        btnSearch.setBorder(BorderFactory.createLineBorder(buttonColor, 2, true));

        btnClear.setBackground(Color.RED);
        btnClear.setForeground(Color.WHITE);
        btnClear.setFocusPainted(false);
        btnClear.setBorder(BorderFactory.createLineBorder(Color.RED, 2, true));

        // Button hover effects
        btnSearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnSearch.setBackground(new Color(70, 180, 255));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnSearch.setBackground(buttonColor);
            }
        });

        btnClear.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnClear.setBackground(new Color(255, 90, 90));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnClear.setBackground(Color.RED);
            }
        });

        // Tooltip for user guidance
        txtSearch.setToolTipText("Enter a topic to search on YouTube");
        btnSearch.setToolTipText("Click to search on YouTube");
        btnClear.setToolTipText("Clear the search field");

        // Add search history functionality
        historyComboBox.setEditable(true);
        historyComboBox.addActionListener(e -> {
            String selectedHistory = (String) historyComboBox.getSelectedItem();
            if (selectedHistory != null && !selectedHistory.isEmpty()) {
                txtSearch.setText(selectedHistory);
            }
        });

        // Load the search history into the combo box
        loadSearchHistory(historyComboBox);

        // Input validation: Disable search button if the input is empty
        txtSearch.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                btnSearch.setEnabled(!txtSearch.getText().trim().isEmpty());
            }
        });

        // Initially disable the search button if the text field is empty
        btnSearch.setEnabled(false);

        // Action for the search button: Open YouTube search results
        btnSearch.addActionListener(e -> {
            String topic = txtSearch.getText().trim();
            if (!topic.isEmpty()) {
                try {
                    // Open the URL in the default browser directly without any loading page
                    Desktop.getDesktop().browse(new URI("https://www.youtube.com/results?search_query=" + topic));

                    // Add the topic to history
                    if (!searchHistory.contains(topic)) {
                        searchHistory.add(0, topic);
                        loadSearchHistory(historyComboBox);
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(frame, "Error opening YouTube.");
                }
            }
        });

        // Clear the search field when the Clear button is pressed
        btnClear.addActionListener(e -> {
            txtSearch.setText("");
            btnSearch.setEnabled(false);
        });

        // Add components to the frame
        frame.add(lblSearch);
        frame.add(txtSearch);
        frame.add(btnSearch);
        frame.add(btnClear);
        frame.add(historyComboBox);

        // Set frame properties
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    // Load the search history into the combo box
    private static void loadSearchHistory(JComboBox<String> historyComboBox) {
        historyComboBox.removeAllItems();
        for (String history : searchHistory) {
            historyComboBox.addItem(history);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(SearchAndLearn::launch);
    }
}

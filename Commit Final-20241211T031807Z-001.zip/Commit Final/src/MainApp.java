import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MainApp {
    public static void main(String[] args) {
        // Create frame and setup basic properties
        JFrame frame = new JFrame("Advanced Student Learning Tracker");
        frame.setSize(800, 1200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null); // Center the window
        frame.setResizable(false);
        
        // Set gradient background for a modern feel
        frame.getContentPane().setBackground(new Color(40, 40, 40));
        GradientPanel gradientPanel = new GradientPanel();
        frame.setContentPane(gradientPanel);
        
        // Create buttons
        JButton btnSearch = createModernButton("Search and Learn");
        JButton btnAssess = createModernButton("Skill Assessment");
        JButton btnTrack = createModernButton("Activity Tracking");
        JButton btnRewards = createModernButton("Rewards and Challenges");

        // Set a layout for flexible button placement (using SpringLayout)
        SpringLayout layout = new SpringLayout();
        gradientPanel.setLayout(layout);

        // Add buttons to the frame
        gradientPanel.add(btnSearch);
        gradientPanel.add(btnAssess);
        gradientPanel.add(btnTrack);
        gradientPanel.add(btnRewards);

        // Position the buttons in a way that feels like a flowchart but is still responsive
        layout.putConstraint(SpringLayout.NORTH, btnSearch, 100, SpringLayout.NORTH, gradientPanel);
        layout.putConstraint(SpringLayout.WEST, btnSearch, 50, SpringLayout.WEST, gradientPanel);

        layout.putConstraint(SpringLayout.NORTH, btnAssess, 150, SpringLayout.SOUTH, btnSearch);
        layout.putConstraint(SpringLayout.WEST, btnAssess, 150, SpringLayout.WEST, gradientPanel);

        layout.putConstraint(SpringLayout.NORTH, btnTrack, 150, SpringLayout.SOUTH, btnAssess);
        layout.putConstraint(SpringLayout.WEST, btnTrack, 100, SpringLayout.WEST, gradientPanel);

        layout.putConstraint(SpringLayout.NORTH, btnRewards, 150, SpringLayout.SOUTH, btnTrack);
        layout.putConstraint(SpringLayout.WEST, btnRewards, 200, SpringLayout.WEST, gradientPanel);

        // Add action listeners for navigation
        btnSearch.addActionListener(e -> SearchAndLearn.launch());
        btnAssess.addActionListener(e -> SkillAssessment.launch());
        btnTrack.addActionListener(e -> ActivityTracking.launch());
        btnRewards.addActionListener(e -> RewardsAndChallenges.launch());

        // Display the frame
        frame.setVisible(true);
    }

    // Helper method to create modern buttons with rounded corners and shadows
    private static JButton createModernButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 24)); // Large, bold font
        button.setFocusPainted(false); // Remove focus outline
        button.setBackground(new Color(0, 122, 255)); // Bright blue color
        button.setForeground(Color.WHITE); // White text
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20)); // Padding inside button
        button.setPreferredSize(new Dimension(600, 100)); // Larger button
        button.setOpaque(true); // Ensure the button color fills

        // Set rounded corners and drop shadow effect
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0, 122, 255), 3),
                BorderFactory.createEmptyBorder(10, 20, 10, 20)
        ));

        // Add hover effect with smooth transition
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(new Color(0, 150, 255)); // Lighter blue on hover
                button.setBorder(BorderFactory.createLineBorder(new Color(0, 150, 255), 3));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(new Color(0, 122, 255)); // Reset to original color
                button.setBorder(BorderFactory.createLineBorder(new Color(0, 122, 255), 3));
            }
        });

        return button;
    }

    // Custom JPanel for gradient background
    static class GradientPanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            
            // Create gradient background
            Color color1 = new Color(0, 0, 0); // Dark color
            Color color2 = new Color(40, 40, 40); // Lighter dark color
            GradientPaint gradient = new GradientPaint(0, 0, color1, getWidth(), getHeight(), color2);
            g2d.setPaint(gradient);
            g2d.fillRect(0, 0, getWidth(), getHeight());
        }
    }
}

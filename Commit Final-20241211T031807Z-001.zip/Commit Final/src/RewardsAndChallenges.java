import javax.swing.*;
import java.awt.*;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class RewardsAndChallenges {
    private static int points = 0;
    private static List<String> challengeNames;
    private static List<String> questions;
    private static String topic = "";

    static {
        challengeNames = Arrays.asList(
            "Learn the %s",
            "Master the %s",
            "Conquer the %s",
            "Tackle the %s",
            "Navigate the %s",
            "Face the %s",
            "Overcome the %s",
            "Rise to the %s",
            "Embark on the %s",
            "Grasp the %s"
        );

        questions = Arrays.asList(
            "Can you define the key terms and concepts relevant to %s?",
            "What is the central thesis or argument about %s?",
            "Can you summarize the main points of %s in simpler terms?",
            "What specific evidence supports your understanding of %s?",
            "How does %s connect to broader societal or global issues?",
            "What are the potential consequences of understanding %s?",
            "What assumptions are you making about %s?",
            "What alternative viewpoints exist about %s?",
            "Why is %s important, and who does it affect most?",
            "What are the strongest counterarguments to your understanding of %s?"
        );
    }

    public static void launch() {
        JFrame frame = new JFrame("Rewards and Challenges");
        frame.setSize(800, 600);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel lblTitle = new JLabel("Rewards and Challenges");
        JLabel lblPoints = new JLabel("Points: " + points);
        JTextField txtTopic = new JTextField();
        JButton btnStart = new JButton("Submit Your Learned Topic");
        JButton btnAccept = new JButton("Accept");
        JButton btnDeny = new JButton("Deny");
        JButton btnNext = new JButton("Next Challenge");

        Font font = new Font("Arial", Font.BOLD, 20);

        // Set layout and colors
        frame.setLayout(null);
        frame.getContentPane().setBackground(Color.BLACK);

        lblTitle.setFont(font);
        lblTitle.setForeground(Color.WHITE);

        lblPoints.setFont(font);
        lblPoints.setForeground(Color.WHITE);

        txtTopic.setFont(font);
        btnStart.setFont(font);
        btnAccept.setFont(font);
        btnDeny.setFont(font);
        btnNext.setFont(font);

        lblTitle.setBounds(250, 20, 400, 50);
        txtTopic.setBounds(200, 100, 400, 40);
        btnStart.setBounds(200, 150, 400, 40);
        lblPoints.setBounds(300, 200, 200, 40);
        btnAccept.setBounds(200, 300, 150, 40);
        btnDeny.setBounds(400, 300, 150, 40);
        btnNext.setBounds(300, 400, 200, 40);

        txtTopic.setBackground(Color.WHITE);
        txtTopic.setForeground(Color.BLACK);

        btnStart.setBackground(Color.BLUE);
        btnStart.setForeground(Color.WHITE);

        btnAccept.setBackground(Color.GREEN);
        btnAccept.setForeground(Color.WHITE);

        btnDeny.setBackground(Color.RED);
        btnDeny.setForeground(Color.WHITE);

        btnNext.setBackground(Color.YELLOW);
        btnNext.setForeground(Color.BLACK);

        frame.add(lblTitle);
        frame.add(txtTopic);
        frame.add(btnStart);
        frame.add(lblPoints);
        frame.add(btnAccept);
        frame.add(btnDeny);
        frame.add(btnNext);

        btnAccept.setVisible(false);
        btnDeny.setVisible(false);
        btnNext.setVisible(false);

        btnStart.addActionListener(e -> {
            topic = txtTopic.getText().trim();
            if (!topic.isEmpty()) {
                showChallenge(frame, lblTitle);
                btnAccept.setVisible(true);
                btnDeny.setVisible(true);
                btnNext.setVisible(true);
            } else {
                JOptionPane.showMessageDialog(frame, "Please enter a topic!");
            }
        });

        btnAccept.addActionListener(e -> {
            points += 10;
            lblPoints.setText("Points: " + points);
            JOptionPane.showMessageDialog(frame, "Challenge accepted! Answer questions to earn points.");
            askQuestions(frame);
        });

        btnDeny.addActionListener(e -> JOptionPane.showMessageDialog(frame, "Challenge declined. Try another one."));

        btnNext.addActionListener(e -> showChallenge(frame, lblTitle));

        frame.setVisible(true);
    }

    private static void showChallenge(JFrame frame, JLabel lblTitle) {
        Random random = new Random();
        String challengeName = challengeNames.get(random.nextInt(challengeNames.size()));
        lblTitle.setText(String.format(challengeName, topic));
    }

    private static void askQuestions(JFrame frame) {
        Random random = new Random();
        for (int i = 0; i < 5; i++) {
            String question = questions.get(random.nextInt(questions.size()));
            String userAnswer = JOptionPane.showInputDialog(frame, String.format(question, topic));
            if (userAnswer != null && !userAnswer.trim().isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Answer recorded! Keep going.");
            } else {
                JOptionPane.showMessageDialog(frame, "Please provide an answer before continuing.");
            }
        }
    }
}

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ActivityTracking {
    private static int seconds = 0, minutes = 0, hours = 0;
    private static Timer timer;
    private static JLabel lblTimer;
    private static boolean isRunning = false;
    private static JButton btnStart, btnStop, btnReset;

    public static void launch() {
        JFrame frame = new JFrame("Activity Tracking");
        frame.setSize(800, 600); // 2x size
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Modern label with custom font and gradient
        lblTimer = new JLabel("00:00:00", SwingConstants.CENTER);
        lblTimer.setFont(new Font("Arial", Font.BOLD, 60));
        lblTimer.setForeground(Color.WHITE);

        // Buttons
        btnStart = new JButton("Start");
        btnStop = new JButton("Stop");
        btnReset = new JButton("Reset");

        // Customize fonts for buttons
        Font buttonFont = new Font("Arial", Font.BOLD, 24);
        btnStart.setFont(buttonFont);
        btnStop.setFont(buttonFont);
        btnReset.setFont(buttonFont);

        // Layout customizations
        frame.setLayout(null);
        frame.getContentPane().setBackground(new Color(32, 32, 32)); // Dark background color

        lblTimer.setBounds(250, 100, 300, 100); // Centered
        btnStart.setBounds(100, 300, 150, 50);
        btnStop.setBounds(325, 300, 150, 50);
        btnReset.setBounds(550, 300, 150, 50); // Position Reset Button

        // Style buttons with rounded corners, background and hover effects
        styleButton(btnStart);
        styleButton(btnStop);
        styleButton(btnReset);

        // Add components to the frame
        frame.add(lblTimer);
        frame.add(btnStart);
        frame.add(btnStop);
        frame.add(btnReset);

        // Timer Logic
        timer = new Timer(1000, e -> {
            if (isRunning) {
                seconds++;
                if (seconds == 60) {
                    seconds = 0;
                    minutes++;
                }
                if (minutes == 60) {
                    minutes = 0;
                    hours++;
                }
                updateTimerLabel();
            }
        });

        // Start Button Action
        btnStart.addActionListener(e -> {
            if (!isRunning) {
                timer.start();
                isRunning = true;
                btnStart.setText("Pause");
            } else {
                timer.stop();
                isRunning = false;
                btnStart.setText("Resume");
            }
        });

        // Stop Button Action
        btnStop.addActionListener(e -> {
            timer.stop();
            isRunning = false;
            btnStart.setText("Start");
        });

        // Reset Button Action
        btnReset.addActionListener(e -> {
            timer.stop();
            isRunning = false;
            seconds = 0;
            minutes = 0;
            hours = 0;
            updateTimerLabel();
            btnStart.setText("Start");
        });

        frame.setVisible(true);
    }

    // Method to update the timer label
    private static void updateTimerLabel() {
        String time = String.format("%02d:%02d:%02d", hours, minutes, seconds);
        lblTimer.setText(time);
    }

    // Style the buttons for modern UI
    private static void styleButton(JButton button) {
        button.setBackground(new Color(65, 105, 225)); // Bright Blue Background
        button.setForeground(Color.WHITE);
        button.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
        button.setFocusPainted(false);
        button.setContentAreaFilled(false);
        button.setOpaque(true);
        
        // Button Hover Effects
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(30, 144, 255)); // Lighter Blue on Hover
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(65, 105, 225)); // Original Blue
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ActivityTracking::launch);
    }
}
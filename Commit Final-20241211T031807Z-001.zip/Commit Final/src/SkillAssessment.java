import javax.swing.*;
import java.awt.*;

public class SkillAssessment {
    public static void launch() {
        JFrame frame = new JFrame("Skill Assessment");
        frame.setSize(800, 600); // 2x size
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel lblTopic = new JLabel("Enter Topic:");
        JTextField txtTopic = new JTextField();
        JButton btnQuiz = new JButton("Start Quiz");

        Font font = new Font("Arial", Font.BOLD, 24); // Scaled font

        // Set layout and colors
        frame.setLayout(null);
        frame.getContentPane().setBackground(Color.BLACK);
        lblTopic.setFont(font);
        lblTopic.setForeground(Color.WHITE);

        txtTopic.setFont(font);
        btnQuiz.setFont(font);

        lblTopic.setBounds(50, 50, 200, 50); // Scaled bounds
        txtTopic.setBounds(300, 50, 400, 50);
        btnQuiz.setBounds(200, 200, 400, 50);

        btnQuiz.setBackground(Color.BLUE);
        btnQuiz.setForeground(Color.WHITE);

        frame.add(lblTopic);
        frame.add(txtTopic);
        frame.add(btnQuiz);

        btnQuiz.addActionListener(e -> {
            String topic = txtTopic.getText();
            if (!topic.isEmpty()) {
                Quiz.startQuiz(topic); // Ensure this method is implemented
            } else {
                JOptionPane.showMessageDialog(frame, "Please enter a topic.");
            }
        });

        frame.setVisible(true);
    }
}
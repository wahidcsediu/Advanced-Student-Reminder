import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class Quiz {
    private static ArrayList<String> questions = new ArrayList<>();
    private static int currentQuestion = 0;
    private static int score = 0;

    public static void startQuiz(String topic) {
        // Generate questions (you can customize or use a placeholder here)
        generateQuestions(topic);

        if (questions.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No questions available for the topic.");
            return;
        }

        showQuestion();
    }

    private static void generateQuestions(String topic) {
        // Placeholder for question generation logic (customize as needed)
        questions.clear();
        questions.add("What is " + topic + "?");
        questions.add("Explain the basics of " + topic + ".");
        questions.add("List advantages of " + topic + ".");
        questions.add("What are the challenges of " + topic + "?");
        questions.add("Describe an example of " + topic + " in action.");
    }

    private static void showQuestion() {
        JFrame frame = new JFrame("Quiz");
        frame.setSize(800, 600); // 2x size
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel lblQuestion = new JLabel(questions.get(currentQuestion));
        JTextField txtAnswer = new JTextField();
        JButton btnNext = new JButton("Next");

        Font font = new Font("Arial", Font.BOLD, 24); // Scaled font
        frame.setLayout(null);
        frame.getContentPane().setBackground(Color.BLACK);

        lblQuestion.setFont(font);
        lblQuestion.setForeground(Color.WHITE);

        txtAnswer.setFont(font);
        btnNext.setFont(font);

        lblQuestion.setBounds(50, 50, 700, 100); // Scaled bounds
        txtAnswer.setBounds(50, 200, 700, 50);
        btnNext.setBounds(300, 400, 200, 50);

        btnNext.setBackground(Color.BLUE);
        btnNext.setForeground(Color.WHITE);

        frame.add(lblQuestion);
        frame.add(txtAnswer);
        frame.add(btnNext);

        btnNext.addActionListener(e -> {
            String answer = txtAnswer.getText();
            if (!answer.isEmpty()) {
                // Process the answer (for now, just move to the next question)
                score++; // Increment score (placeholder logic)
                currentQuestion++;
                frame.dispose();

                if (currentQuestion < questions.size()) {
                    showQuestion();
                } else {
                    showResults();
                }
            } else {
                JOptionPane.showMessageDialog(frame, "Please enter an answer.");
            }
        });

        frame.setVisible(true);
    }

    private static void showResults() {
        JOptionPane.showMessageDialog(null, "Quiz Complete! Your score: " + score + "/" + questions.size());
        // Reset quiz state
        questions.clear();
        currentQuestion = 0;
        score = 0;
    }
}
